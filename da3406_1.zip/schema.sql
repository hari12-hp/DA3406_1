PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- ScrollSense Assignment 1
-- Roll number: DA24B005
-- SQLite 3.44+

CREATE TABLE app_user (
    user_id INTEGER PRIMARY KEY,
    handle TEXT NOT NULL,
    display_name TEXT NOT NULL,
    account_state TEXT NOT NULL CHECK (account_state IN ('active','deactivated','pending_deletion')),
    created_at TEXT NOT NULL,
    deletion_requested_at TEXT,
    deletion_recover_until TEXT,
    CHECK (handle = trim(handle) AND length(handle) > 0),
    CHECK ((account_state = 'pending_deletion' AND deletion_requested_at IS NOT NULL AND deletion_recover_until IS NOT NULL)
        OR (account_state <> 'pending_deletion' AND deletion_requested_at IS NULL AND deletion_recover_until IS NULL))
);

-- SQLite partial unique index handles the "active accounts only" half of the rule.
-- NOCASE is ASCII-only; clients should normalize non-ASCII handles before admission.
CREATE UNIQUE INDEX uq_active_handle_nocase
ON app_user(handle COLLATE NOCASE)
WHERE account_state = 'active';

CREATE TABLE auth_identity (
    auth_identity_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    provider TEXT NOT NULL CHECK (provider IN ('phone','google')),
    provider_key TEXT NOT NULL,
    verified_at TEXT,
    UNIQUE(provider, provider_key)
);

CREATE TABLE handle_history (
    handle_history_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    old_handle TEXT NOT NULL,
    new_handle TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    CHECK (trim(new_handle) <> ''),
    CHECK (old_handle <> new_handle)
);

CREATE TABLE interest_category (
    interest_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1))
);

CREATE TABLE user_declared_interest (
    user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    interest_id INTEGER NOT NULL REFERENCES interest_category(interest_id) ON DELETE RESTRICT,
    declared_at TEXT NOT NULL,
    PRIMARY KEY (user_id, interest_id)
);

CREATE TABLE user_inferred_interest (
    user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    interest_id INTEGER NOT NULL REFERENCES interest_category(interest_id) ON DELETE RESTRICT,
    refreshed_at TEXT NOT NULL,
    confidence REAL NOT NULL CHECK (confidence >= 0.0 AND confidence <= 1.0),
    PRIMARY KEY (user_id, interest_id, refreshed_at)
);

CREATE TABLE user_interest_suppression (
    user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    interest_id INTEGER NOT NULL REFERENCES interest_category(interest_id) ON DELETE RESTRICT,
    suppressed_at TEXT NOT NULL,
    lifted_at TEXT,
    CHECK (lifted_at IS NULL OR lifted_at > suppressed_at),
    PRIMARY KEY (user_id, interest_id, suppressed_at)
);

CREATE TABLE user_state_period (
    user_state_period_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    account_state TEXT NOT NULL CHECK (account_state IN ('active','deactivated','pending_deletion')),
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    CHECK (valid_to IS NULL OR valid_to > valid_from)
);

CREATE TABLE creator (
    creator_id INTEGER PRIMARY KEY REFERENCES app_user(user_id) ON DELETE CASCADE,
    creator_since TEXT NOT NULL,
    payout_status TEXT NOT NULL CHECK (payout_status IN ('eligible','hold','not_eligible'))
);

CREATE TABLE monetization_tier (
    tier_code TEXT PRIMARY KEY,
    tier_name TEXT NOT NULL UNIQUE,
    min_followers INTEGER NOT NULL CHECK (min_followers >= 0)
);

CREATE TABLE creator_tier_period (
    creator_id INTEGER NOT NULL REFERENCES creator(creator_id) ON DELETE CASCADE,
    tier_code TEXT NOT NULL REFERENCES monetization_tier(tier_code) ON DELETE RESTRICT,
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    PRIMARY KEY (creator_id, valid_from),
    CHECK (valid_to IS NULL OR valid_to > valid_from)
);

CREATE TABLE audio_track (
    track_id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    source_kind TEXT NOT NULL CHECK (source_kind IN ('original','licensed')),
    catalogue_ref TEXT
);

CREATE TABLE video (
    video_id INTEGER PRIMARY KEY,
    owner_id INTEGER NOT NULL REFERENCES creator(creator_id) ON DELETE RESTRICT,
    duration_ms INTEGER NOT NULL CHECK (duration_ms BETWEEN 20000 AND 90000),
    caption TEXT NOT NULL,
    audio_track_id INTEGER REFERENCES audio_track(track_id) ON DELETE SET NULL,
    uploaded_at TEXT NOT NULL,
    CHECK (length(caption) <= 2200)
);

CREATE TABLE hashtag (
    hashtag_id INTEGER PRIMARY KEY,
    tag_text TEXT NOT NULL UNIQUE
);

CREATE TABLE video_hashtag (
    video_id INTEGER NOT NULL REFERENCES video(video_id) ON DELETE CASCADE,
    hashtag_id INTEGER NOT NULL REFERENCES hashtag(hashtag_id) ON DELETE RESTRICT,
    PRIMARY KEY (video_id, hashtag_id)
);

CREATE TABLE moderation_decision (
    decision_id INTEGER PRIMARY KEY,
    video_id INTEGER NOT NULL REFERENCES video(video_id) ON DELETE CASCADE,
    decided_at TEXT NOT NULL,
    moderator_kind TEXT NOT NULL CHECK (moderator_kind IN ('automated_classifier','human_reviewer')),
    moderator_ref TEXT NOT NULL,
    reason_code TEXT NOT NULL
);

CREATE TABLE video_moderation_period (
    video_id INTEGER NOT NULL REFERENCES video(video_id) ON DELETE CASCADE,
    decision_id INTEGER NOT NULL REFERENCES moderation_decision(decision_id) ON DELETE RESTRICT,
    state TEXT NOT NULL CHECK (state IN ('pending','live','age_restricted','demoted','taken_down')),
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    PRIMARY KEY (video_id, valid_from),
    CHECK (valid_to IS NULL OR valid_to > valid_from)
);

CREATE TABLE follow (
    follower_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    followed_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    PRIMARY KEY (follower_id, followed_id, started_at),
    CHECK (follower_id <> followed_id),
    CHECK (ended_at IS NULL OR ended_at > started_at)
);

CREATE TABLE block (
    blocker_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    blocked_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    blocked_at TEXT NOT NULL,
    unblocked_at TEXT,
    PRIMARY KEY (blocker_id, blocked_id, blocked_at),
    CHECK (blocker_id <> blocked_id),
    CHECK (unblocked_at IS NULL OR unblocked_at > blocked_at)
);

CREATE TABLE mute (
    muter_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    muted_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    muted_at TEXT NOT NULL,
    unmuted_at TEXT,
    PRIMARY KEY (muter_id, muted_id, muted_at),
    CHECK (muter_id <> muted_id),
    CHECK (unmuted_at IS NULL OR unmuted_at > muted_at)
);

CREATE TABLE impression (
    impression_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    video_id INTEGER NOT NULL REFERENCES video(video_id) ON DELETE CASCADE,
    impression_at TEXT NOT NULL,
    feed_position INTEGER NOT NULL CHECK (feed_position >= 1),
    rank_model_version TEXT NOT NULL,
    CHECK (length(rank_model_version) > 0)
);

CREATE TABLE view_segment (
    view_segment_id INTEGER PRIMARY KEY,
    impression_id INTEGER NOT NULL REFERENCES impression(impression_id) ON DELETE CASCADE,
    started_at TEXT NOT NULL,
    ended_at TEXT NOT NULL,
    watch_ms INTEGER NOT NULL CHECK (watch_ms > 0),
    completed INTEGER NOT NULL CHECK (completed IN (0,1)),
    recommendation_id INTEGER REFERENCES agent_recommendation(recommendation_id) ON DELETE SET NULL,
    CHECK (ended_at >= started_at)
);

CREATE TABLE engagement_signal (
    signal_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    video_id INTEGER NOT NULL REFERENCES video(video_id) ON DELETE CASCADE,
    signal_type TEXT NOT NULL CHECK (signal_type IN ('like','like_retraction','save','share','comment','follow_from_feed','not_interested','report')),
    occurred_at TEXT NOT NULL,
    share_destination TEXT,
    CHECK ((signal_type = 'share' AND share_destination IN ('whatsapp','instagram','copied_link'))
        OR (signal_type <> 'share' AND share_destination IS NULL))
);

CREATE TABLE like_state (
    user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    video_id INTEGER NOT NULL REFERENCES video(video_id) ON DELETE CASCADE,
    liked_at TEXT NOT NULL,
    retracted_at TEXT,
    PRIMARY KEY (user_id, video_id),
    CHECK (retracted_at IS NULL OR retracted_at >= liked_at)
);

CREATE TABLE agent_session (
    session_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    started_at TEXT NOT NULL,
    ended_at TEXT
);

CREATE TABLE agent_turn (
    turn_id INTEGER PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES agent_session(session_id) ON DELETE CASCADE,
    turn_no INTEGER NOT NULL CHECK (turn_no >= 1),
    user_message TEXT NOT NULL,
    assistant_message TEXT NOT NULL,
    produced_at TEXT NOT NULL,
    prompt_version_id INTEGER NOT NULL REFERENCES prompt_template_version(prompt_version_id) ON DELETE RESTRICT,
    model_id INTEGER NOT NULL REFERENCES model_registry(model_id) ON DELETE RESTRICT,
    temperature REAL NOT NULL CHECK (temperature >= 0 AND temperature <= 2),
    UNIQUE(session_id, turn_no)
);

CREATE TABLE prompt_template_version (
    prompt_version_id INTEGER PRIMARY KEY,
    template_name TEXT NOT NULL,
    version_no INTEGER NOT NULL CHECK (version_no >= 1),
    template_text TEXT NOT NULL,
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    UNIQUE(template_name, version_no),
    CHECK (valid_to IS NULL OR valid_to > valid_from)
);

CREATE TABLE model_registry (
    model_id INTEGER PRIMARY KEY,
    model_name TEXT NOT NULL UNIQUE,
    vendor TEXT NOT NULL
);

CREATE TABLE model_price_period (
    model_id INTEGER NOT NULL REFERENCES model_registry(model_id) ON DELETE CASCADE,
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    input_rate_per_million REAL NOT NULL CHECK (input_rate_per_million >= 0),
    output_rate_per_million REAL NOT NULL CHECK (output_rate_per_million >= 0),
    cached_input_rate_per_million REAL NOT NULL CHECK (cached_input_rate_per_million >= 0),
    PRIMARY KEY (model_id, valid_from),
    CHECK (valid_to IS NULL OR valid_to > valid_from)
);

CREATE TABLE turn_usage (
    turn_id INTEGER PRIMARY KEY REFERENCES agent_turn(turn_id) ON DELETE CASCADE,
    model_id INTEGER NOT NULL REFERENCES model_registry(model_id) ON DELETE RESTRICT,
    input_tokens INTEGER NOT NULL CHECK (input_tokens >= 0),
    output_tokens INTEGER NOT NULL CHECK (output_tokens >= 0),
    cached_tokens INTEGER NOT NULL CHECK (cached_tokens >= 0),
    priced_at TEXT NOT NULL,
    input_rate REAL NOT NULL CHECK (input_rate >= 0),
    output_rate REAL NOT NULL CHECK (output_rate >= 0),
    cached_input_rate REAL NOT NULL CHECK (cached_input_rate >= 0)
);


CREATE TABLE turn_judge_score (
    turn_id INTEGER PRIMARY KEY REFERENCES agent_turn(turn_id) ON DELETE CASCADE,
    judged_at TEXT NOT NULL,
    helpfulness REAL NOT NULL CHECK (helpfulness BETWEEN 1 AND 5),
    groundedness REAL NOT NULL CHECK (groundedness BETWEEN 1 AND 5),
    safety REAL NOT NULL CHECK (safety BETWEEN 1 AND 5),
    overall_score REAL NOT NULL CHECK (overall_score BETWEEN 1 AND 5)
);

CREATE TABLE user_explanation_rating (
    turn_id INTEGER PRIMARY KEY REFERENCES agent_turn(turn_id) ON DELETE CASCADE,
    rated_at TEXT NOT NULL,
    rating INTEGER NOT NULL CHECK (rating IN (-1,1))
);

CREATE TABLE tool_definition (
    tool_id INTEGER PRIMARY KEY,
    tool_name TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL
);

CREATE TABLE tool_call (
    tool_call_id INTEGER PRIMARY KEY,
    turn_id INTEGER NOT NULL REFERENCES agent_turn(turn_id) ON DELETE CASCADE,
    parent_tool_call_id INTEGER REFERENCES tool_call(tool_call_id) ON DELETE CASCADE,
    tool_id INTEGER NOT NULL REFERENCES tool_definition(tool_id) ON DELETE RESTRICT,
    started_at TEXT NOT NULL,
    ended_at TEXT NOT NULL,
    arguments_json TEXT NOT NULL CHECK (json_valid(arguments_json)),
    result_text TEXT,
    latency_ms INTEGER NOT NULL CHECK (latency_ms >= 0),
    errored INTEGER NOT NULL CHECK (errored IN (0,1)),
    CHECK (ended_at >= started_at)
);

CREATE TABLE agent_recommendation (
    recommendation_id INTEGER PRIMARY KEY,
    turn_id INTEGER NOT NULL REFERENCES agent_turn(turn_id) ON DELETE CASCADE,
    video_id INTEGER NOT NULL REFERENCES video(video_id) ON DELETE CASCADE,
    shelf_position INTEGER NOT NULL CHECK (shelf_position >= 1),
    recommended_at TEXT NOT NULL,
    UNIQUE(turn_id, shelf_position)
);

-- Handle changes: no more than two per rolling 365-day period.
CREATE TRIGGER trg_handle_change_limit
BEFORE UPDATE OF handle ON app_user
WHEN NEW.handle <> OLD.handle
BEGIN
    SELECT CASE WHEN (
        SELECT COUNT(*) FROM handle_history h
        WHERE h.user_id = OLD.user_id
          AND julianday(h.changed_at) >= julianday('now') - 365
    ) >= 2 THEN RAISE(ABORT, 'handle change limit: at most two changes in 365 days') END;
END;

CREATE TRIGGER trg_handle_change_audit
AFTER UPDATE OF handle ON app_user
WHEN NEW.handle <> OLD.handle
BEGIN
    INSERT INTO handle_history(user_id, old_handle, new_handle, changed_at)
    VALUES(OLD.user_id, OLD.handle, NEW.handle, datetime('now'));
END;

CREATE TRIGGER trg_block_ends_follows
AFTER INSERT ON block
BEGIN
    UPDATE follow SET ended_at = NEW.blocked_at
    WHERE ended_at IS NULL
      AND ((follower_id = NEW.blocker_id AND followed_id = NEW.blocked_id)
        OR (follower_id = NEW.blocked_id AND followed_id = NEW.blocker_id));
END;

CREATE TRIGGER trg_no_tool_cycle
BEFORE INSERT ON tool_call
WHEN NEW.parent_tool_call_id IS NOT NULL
BEGIN
    WITH RECURSIVE ancestors(x) AS (
        SELECT NEW.parent_tool_call_id
        UNION ALL
        SELECT tc.parent_tool_call_id
        FROM tool_call tc JOIN ancestors a ON tc.tool_call_id = a.x
        WHERE tc.parent_tool_call_id IS NOT NULL
    )
    SELECT CASE WHEN EXISTS (SELECT 1 FROM ancestors WHERE x = NEW.tool_call_id)
                THEN RAISE(ABORT, 'tool call parent cycle') END;
END;

CREATE TRIGGER trg_no_tool_cycle_update
BEFORE UPDATE OF parent_tool_call_id ON tool_call
WHEN NEW.parent_tool_call_id IS NOT NULL
BEGIN
    WITH RECURSIVE ancestors(x) AS (
        SELECT NEW.parent_tool_call_id
        UNION ALL
        SELECT tc.parent_tool_call_id
        FROM tool_call tc JOIN ancestors a ON tc.tool_call_id = a.x
        WHERE tc.parent_tool_call_id IS NOT NULL
    )
    SELECT CASE WHEN EXISTS (SELECT 1 FROM ancestors WHERE x = NEW.tool_call_id)
                THEN RAISE(ABORT, 'tool call parent cycle') END;
END;

CREATE TRIGGER trg_user_state_no_overlap
BEFORE INSERT ON user_state_period
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM user_state_period p
        WHERE p.user_id = NEW.user_id
          AND (NEW.valid_to IS NULL OR p.valid_from < NEW.valid_to)
          AND (p.valid_to IS NULL OR NEW.valid_from < p.valid_to)
    ) THEN RAISE(ABORT, 'overlapping user state period') END;
END;

CREATE TRIGGER trg_creator_tier_no_overlap
BEFORE INSERT ON creator_tier_period
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM creator_tier_period p
        WHERE p.creator_id = NEW.creator_id
          AND (NEW.valid_to IS NULL OR p.valid_from < NEW.valid_to)
          AND (p.valid_to IS NULL OR NEW.valid_from < p.valid_to)
    ) THEN RAISE(ABORT, 'overlapping creator tier period') END;
END;

CREATE TRIGGER trg_model_price_no_overlap
BEFORE INSERT ON model_price_period
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM model_price_period p
        WHERE p.model_id = NEW.model_id
          AND (NEW.valid_to IS NULL OR p.valid_from < NEW.valid_to)
          AND (p.valid_to IS NULL OR NEW.valid_from < p.valid_to)
    ) THEN RAISE(ABORT, 'overlapping model price period') END;
END;

CREATE TRIGGER trg_prompt_version_no_overlap
BEFORE INSERT ON prompt_template_version
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM prompt_template_version p
        WHERE p.template_name = NEW.template_name
          AND (NEW.valid_to IS NULL OR p.valid_from < NEW.valid_to)
          AND (p.valid_to IS NULL OR NEW.valid_from < p.valid_to)
    ) THEN RAISE(ABORT, 'overlapping prompt version') END;
END;

CREATE TRIGGER trg_moderation_no_overlap
BEFORE INSERT ON video_moderation_period
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM video_moderation_period p
        WHERE p.video_id = NEW.video_id
          AND (NEW.valid_to IS NULL OR p.valid_from < NEW.valid_to)
          AND (p.valid_to IS NULL OR NEW.valid_from < p.valid_to)
    ) THEN RAISE(ABORT, 'overlapping moderation period') END;
END;

CREATE TRIGGER trg_user_state_update_no_overlap
BEFORE UPDATE OF valid_from, valid_to ON user_state_period
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM user_state_period p
        WHERE p.user_id = NEW.user_id
          AND p.user_state_period_id <> OLD.user_state_period_id
          AND (NEW.valid_to IS NULL OR p.valid_from < NEW.valid_to)
          AND (p.valid_to IS NULL OR NEW.valid_from < p.valid_to)
    ) THEN RAISE(ABORT, 'overlapping user state period') END;
END;

CREATE TRIGGER trg_creator_tier_update_no_overlap
BEFORE UPDATE OF valid_from, valid_to ON creator_tier_period
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM creator_tier_period p
        WHERE p.creator_id = NEW.creator_id
          AND NOT (p.creator_id = OLD.creator_id AND p.valid_from = OLD.valid_from)
          AND (NEW.valid_to IS NULL OR p.valid_from < NEW.valid_to)
          AND (p.valid_to IS NULL OR NEW.valid_from < p.valid_to)
    ) THEN RAISE(ABORT, 'overlapping creator tier period') END;
END;

CREATE TRIGGER trg_model_price_update_no_overlap
BEFORE UPDATE OF valid_from, valid_to ON model_price_period
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM model_price_period p
        WHERE p.model_id = NEW.model_id
          AND NOT (p.model_id = OLD.model_id AND p.valid_from = OLD.valid_from)
          AND (NEW.valid_to IS NULL OR p.valid_from < NEW.valid_to)
          AND (p.valid_to IS NULL OR NEW.valid_from < p.valid_to)
    ) THEN RAISE(ABORT, 'overlapping model price period') END;
END;

CREATE TRIGGER trg_prompt_version_update_no_overlap
BEFORE UPDATE OF template_name, valid_from, valid_to ON prompt_template_version
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM prompt_template_version p
        WHERE p.template_name = NEW.template_name
          AND p.prompt_version_id <> OLD.prompt_version_id
          AND (NEW.valid_to IS NULL OR p.valid_from < NEW.valid_to)
          AND (p.valid_to IS NULL OR NEW.valid_from < p.valid_to)
    ) THEN RAISE(ABORT, 'overlapping prompt version') END;
END;

CREATE TRIGGER trg_moderation_update_no_overlap
BEFORE UPDATE OF valid_from, valid_to ON video_moderation_period
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM video_moderation_period p
        WHERE p.video_id = NEW.video_id
          AND NOT (p.video_id = OLD.video_id AND p.valid_from = OLD.valid_from)
          AND (NEW.valid_to IS NULL OR p.valid_from < NEW.valid_to)
          AND (p.valid_to IS NULL OR NEW.valid_from < p.valid_to)
    ) THEN RAISE(ABORT, 'overlapping moderation period') END;
END;

CREATE INDEX idx_impression_video_time ON impression(video_id, impression_at);
CREATE INDEX idx_impression_user_time ON impression(user_id, impression_at);
CREATE INDEX idx_view_segment_impression ON view_segment(impression_id);
CREATE INDEX idx_signal_user_video_time ON engagement_signal(user_id, video_id, occurred_at);
CREATE INDEX idx_recommendation_turn_video ON agent_recommendation(turn_id, video_id);
CREATE INDEX idx_tool_call_turn_parent ON tool_call(turn_id, parent_tool_call_id);
CREATE INDEX idx_creator_tier_lookup ON creator_tier_period(creator_id, valid_from, valid_to);
CREATE INDEX idx_moderation_lookup ON video_moderation_period(video_id, valid_from, valid_to);
CREATE INDEX idx_price_lookup ON model_price_period(model_id, valid_from, valid_to);
CREATE INDEX idx_turn_usage_model_time ON turn_usage(model_id, priced_at);
CREATE INDEX idx_state_lookup ON user_state_period(user_id, valid_from, valid_to);
