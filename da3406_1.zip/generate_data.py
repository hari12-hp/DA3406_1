import argparse, hashlib, os, random, sqlite3, math
from datetime import datetime, timedelta, timezone

ROLL = 'DA24B005'
SEED = int.from_bytes(hashlib.sha256(ROLL.encode()).digest()[:8], 'big')
N_USERS = 5000
N_CREATORS = 1800
N_VIDEOS = 20000
N_IMPRESSIONS = 300000
N_SESSIONS = 2000
BASE = datetime(2026, 8, 31, 12, 0, 0, tzinfo=timezone.utc)

INTERESTS = ['ai','gaming','cricket','music','movies','fitness','food','travel','coding','fashion','science','comedy','finance','books','football','photography']
TIER_ROWS = [('bronze','Bronze',0),('silver','Silver',1000),('gold','Gold',10000),('platinum','Platinum',50000)]
TOOLS = [('search_videos','Search clips by text and filters'),('get_user_history','Fetch recent viewing history'),('fetch_trending_audio','Get trending sounds for a region'),('lookup_creator','Fetch creator metadata'),('rerank_shelf','Re-rank candidate clips')]
MODELS = [('gpt-4o-mini','OpenAI'),('llama-3.1-70b','Meta'),('scrollsense-ft','ScrollSense')]
TEMPLATE_TEXTS = [
('explainer',1,'Explain why this clip was surfaced, using only evidence available at the turn.'),
('explainer',2,'Explain briefly why this clip was surfaced and mention the strongest evidence.'),
('search',1,'Answer conversational video searches and return a shelf of relevant clips.'),
('search',2,'Find the requested clip and return a ranked shelf with concise reasons.')]


def iso(dt): return dt.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')

def parse_iso(s): return datetime.strptime(s,'%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc)

def exec_schema(conn, path):
    with open(path, 'r', encoding='utf-8') as f: conn.executescript(f.read())

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--db',default='scrollsense.db'); ap.add_argument('--scale',type=float,default=1.0); args=ap.parse_args()
    if os.path.exists(args.db): os.remove(args.db)
    rng=random.Random(SEED)
    conn=sqlite3.connect(args.db); conn.execute('PRAGMA foreign_keys=ON'); conn.execute('PRAGMA journal_mode=WAL');
    exec_schema(conn,'schema.sql')
    cur=conn.cursor(); cur.execute('BEGIN')

    # Base dimensions
    cur.executemany('INSERT INTO interest_category(name) VALUES (?)', [(x,) for x in INTERESTS])
    cur.executemany('INSERT INTO monetization_tier(tier_code,tier_name,min_followers) VALUES (?,?,?)', TIER_ROWS)
    cur.executemany('INSERT INTO model_registry(model_name,vendor) VALUES (?,?)', MODELS)
    model_ids={name:i for i,name,i in cur.execute('SELECT model_name, vendor, model_id FROM model_registry')}
    cur.executemany('INSERT INTO tool_definition(tool_name,description) VALUES (?,?)', TOOLS)
    tool_ids={name:i for name,i in cur.execute('SELECT tool_name,tool_id FROM tool_definition')}
    prompt_rows=[]
    for n,v,t in TEMPLATE_TEXTS:
        if n=='explainer' and v==1:
            vf,vt=BASE-timedelta(days=40),BASE-timedelta(days=20)
        elif n=='explainer' and v==2:
            vf,vt=BASE-timedelta(days=20),None
        elif n=='search' and v==1:
            vf,vt=BASE-timedelta(days=50),BASE-timedelta(days=25)
        else:
            vf,vt=BASE-timedelta(days=25),None
        prompt_rows.append((n,v,t,iso(vf),iso(vt) if vt else None))
    cur.executemany('INSERT INTO prompt_template_version(template_name,version_no,template_text,valid_from,valid_to) VALUES (?,?,?,?,?)', prompt_rows)
    pv_ids={(n,v):i for n,v,i in cur.execute('SELECT template_name,version_no,prompt_version_id FROM prompt_template_version')}

    # Users, auth, states
    users=[]; states=[]; auth=[]
    for uid in range(1,N_USERS+1):
        created=BASE-timedelta(days=rng.randint(0,730), hours=rng.randint(0,23))
        r=rng.random(); state='active' if r<0.86 else ('deactivated' if r<0.96 else 'pending_deletion')
        handle=f'user{uid:05d}'
        deletion_req=iso(BASE-timedelta(days=rng.randint(0,29))) if state=='pending_deletion' else None
        recover=iso(parse_iso(deletion_req)+timedelta(days=30)) if deletion_req else None
        users.append((uid,handle,f'User {uid}',state,iso(created),deletion_req,recover))
        states.append((uid,state,iso(created),None))
        if uid%2: auth.append((uid,'phone',f'+9198{uid:08d}',iso(created+timedelta(hours=1))))
        else: auth.append((uid,'google',f'google-{uid:08d}',iso(created+timedelta(hours=1))))
    cur.executemany('INSERT INTO app_user VALUES (?,?,?,?,?,?,?)', users)
    cur.executemany('INSERT INTO auth_identity(user_id,provider,provider_key,verified_at) VALUES (?,?,?,?)', auth)
    cur.executemany('INSERT INTO user_state_period(user_id,account_state,valid_from,valid_to) VALUES (?,?,?,?)', states)

    # Creator subset. follower counts implied by follows; tier periods use realistic evolution.
    creator_ids=sorted(rng.sample(range(1,N_USERS+1),N_CREATORS))
    cur.executemany('INSERT INTO creator(creator_id,creator_since,payout_status) VALUES (?,?,?)', [(u, iso(BASE-timedelta(days=rng.randint(30,700))), rng.choices(['eligible','hold','not_eligible'],[.65,.12,.23])[0]) for u in creator_ids])
    for u in creator_ids:
        start=BASE-timedelta(days=rng.randint(300,700)); cuts=[0]
        if rng.random()<0.75: cuts.append(rng.randint(90,220))
        if rng.random()<0.35: cuts.append(rng.randint(230,340))
        cuts=sorted(set(cuts))
        for j,c in enumerate(cuts):
            vf=start+timedelta(days=c); vt=(start+timedelta(days=cuts[j+1])) if j+1<len(cuts) else None
            tier=TIER_ROWS[min(len(TIER_ROWS)-1, int((c/340)*3)+rng.choice([0,0,1]))][0]
            cur.execute('INSERT INTO creator_tier_period VALUES (?,?,?,?)',(u,tier,iso(vf),iso(vt) if vt else None))

    # Audio and video. About 70% have audio.
    n_tracks=800
    tracks=[]
    for tid in range(1,n_tracks+1):
        kind='licensed' if rng.random()<0.35 else 'original'
        tracks.append((tid, f'Sound {tid:04d}', kind, f'LIC-{tid:04d}' if kind=='licensed' else None))
    cur.executemany('INSERT INTO audio_track VALUES (?,?,?,?)', tracks)
    videos=[]; hashtags=set(); vh=[]
    tag_pool=['ai','python','college','cats','music','fitness','travel','food','coding','comedy','football','movie']
    for vid in range(1,N_VIDEOS+1):
        owner=rng.choice(creator_ids); dur=rng.randint(20000,90000)
        tags=rng.sample(tag_pool,rng.randint(0,3));
        cap=' '.join([f'#{t}' for t in tags] + [f'Clip {vid} from creator {owner}'])
        audio=rng.randint(1,n_tracks) if rng.random()<0.72 else None
        up=BASE-timedelta(days=rng.randint(0,120),hours=rng.randint(0,23),minutes=rng.randint(0,59))
        videos.append((vid,owner,dur,cap,audio,iso(up)))
        for t in tags: hashtags.add(t)
    cur.executemany('INSERT INTO video VALUES (?,?,?,?,?,?)', videos)
    cur.executemany('INSERT INTO hashtag(tag_text) VALUES (?)', [(x,) for x in sorted(hashtags)])
    tag_ids={t:i for t,i in cur.execute('SELECT tag_text,hashtag_id FROM hashtag')}
    for vid,owner,dur,cap,audio,up in videos:
        for t in [x[1:] for x in cap.split() if x.startswith('#')]: vh.append((vid,tag_ids[t]))
    cur.executemany('INSERT INTO video_hashtag VALUES (?,?)',vh)

    # Moderation: two to four periods for some videos.
    decision_id=1
    for vid,owner,dur,cap,audio,up in videos:
        n=1 if rng.random()<0.55 else rng.randint(2,4)
        t=parse_iso(up)+timedelta(hours=rng.randint(1,24)); states_seq=rng.sample(['pending','live','age_restricted','demoted','taken_down'], min(3,n))
        if 'live' not in states_seq: states_seq[0]='live'
        for j in range(n):
            dec=(decision_id,vid,iso(t),'human_reviewer' if rng.random()<.2 else 'automated_classifier', f'reviewer-{rng.randint(1,80)}','routine')
            cur.execute('INSERT INTO moderation_decision VALUES (?,?,?,?,?,?)',dec)
            vt=(t+timedelta(days=rng.randint(1,30))) if j<n-1 else None
            st=states_seq[j % len(states_seq)]
            cur.execute('INSERT INTO video_moderation_period VALUES (?,?,?,?,?)',(vid,decision_id,st,iso(t),iso(vt) if vt else None))
            decision_id+=1
            if vt is not None:
                # Start the next period only after the previous interval closes.
                t = vt + timedelta(hours=rng.randint(2,24))

    # Follows, blocks, mutes. Active follow rows only for simplicity; blocks end matching follows.
    follows=set()
    for _ in range(14000):
        a=rng.randint(1,N_USERS); b=rng.randint(1,N_USERS)
        if a==b or (a,b) in follows: continue
        st=BASE-timedelta(days=rng.randint(1,365)); follows.add((a,b)); cur.execute('INSERT INTO follow VALUES (?,?,?,NULL)',(a,b,iso(st)))
    for _ in range(250):
        a,b=rng.sample(range(1,N_USERS+1),2); bt=BASE-timedelta(days=rng.randint(0,90)); cur.execute('INSERT INTO block VALUES (?,?,?,NULL)',(a,b,iso(bt)))
    for _ in range(500):
        a,b=rng.sample(range(1,N_USERS+1),2); mt=BASE-timedelta(days=rng.randint(0,90)); cur.execute('INSERT INTO mute VALUES (?,?,?,NULL)',(a,b,iso(mt)))

    # Sessions/turns. Each session 1-5 turns. Use current/historical prompt versions.
    sess_rows=[]; turn_rows=[]; turn_usage=[]; rec_rows=[]; tool_rows=[]; judge_rows=[]; rating_rows=[]
    tid=1; rid=1; tcid=1
    for sid in range(1,N_SESSIONS+1):
        uid=rng.randint(1,N_USERS); st=BASE-timedelta(days=rng.randint(0,45),hours=rng.randint(0,23),minutes=rng.randint(0,59))
        nturn=rng.randint(1,5); en=st+timedelta(minutes=rng.randint(1,25))
        sess_rows.append((sid,uid,iso(st),iso(en)))
        for k in range(1,nturn+1):
            pt=pv_ids[rng.choice(list(pv_ids.keys()))]; model=rng.choice(list(model_ids.values())); prod=st+timedelta(minutes=k*2)
            turn_rows.append((tid,sid,k,'find me a clip like this', 'Here are a few candidates.',iso(prod),pt,model,round(rng.choice([0.2,0.4,0.7,1.0]),1)))
            inp=rng.randint(250,1200); out=rng.randint(80,500); cached=rng.randint(0,int(inp*.45))
            # snapshot rates deliberately historical
            rates={list(model_ids.values())[0]:(0.15,0.60,0.05),list(model_ids.values())[1]:(0.30,0.90,0.10),list(model_ids.values())[2]:(0.08,0.22,0.02)}
            ir,orr,cr=rates[model]
            turn_usage.append((tid,model,inp,out,cached,iso(prod),ir,orr,cr))
            # 0-4 tool calls, with nested second-level calls sometimes
            root_ids=[]
            for _ in range(rng.randint(0,3)):
                tool=rng.choice(list(tool_ids.values())); ts=prod+timedelta(seconds=rng.randint(0,5)); te=ts+timedelta(milliseconds=rng.randint(20,700))
                tool_rows.append((tcid,tid,None,tool,iso(ts),iso(te),'{}','ok',int((te-ts).total_seconds()*1000),0))
                root_ids.append(tcid); tcid+=1
            for root in list(root_ids):
                if rng.random()<0.35:
                    tool=rng.choice(list(tool_ids.values())); ts=prod+timedelta(seconds=rng.randint(1,6)); te=ts+timedelta(milliseconds=rng.randint(20,400))
                    tool_rows.append((tcid,tid,root,tool,iso(ts),iso(te),'{}','nested ok',int((te-ts).total_seconds()*1000),0)); tcid+=1
            for pos in range(1,rng.randint(1,6)+1):
                vid=rng.randint(1,N_VIDEOS); rec_rows.append((rid,tid,vid,pos,iso(prod))); rid+=1
            tid+=1
    cur.executemany('INSERT INTO agent_session VALUES (?,?,?,?)',sess_rows)
    cur.executemany('INSERT INTO agent_turn VALUES (?,?,?,?,?,?,?,?,?)',turn_rows)
    cur.executemany('INSERT INTO turn_usage VALUES (?,?,?,?,?,?,?,?,?)',turn_usage)
    cur.executemany('INSERT INTO tool_call VALUES (?,?,?,?,?,?,?,?,?,?)',tool_rows)
    session_users={sid:uid for sid,uid,st,en in sess_rows}
    rec_meta={rid:(turn_id, session_users[next(sid for tid2,sid,tn,*_ in turn_rows if tid2==turn_id)], vid, pos) for rid,turn_id,vid,pos,ra in rec_rows}
    for tr in turn_rows:
        turn_id=tr[0]
        if rng.random() < 0.28:
            j=rng.choice([3.2,3.8,4.2,4.5,4.8,5.0])
            h=max(1,min(5,j+rng.uniform(-.4,.4))); g=max(1,min(5,j+rng.uniform(-.4,.4))); sf=max(1,min(5,j+rng.uniform(-.4,.4)))
            overall=round((h+g+sf)/3,2)
            judge_rows.append((turn_id, tr[5], round(h,2), round(g,2), round(sf,2), overall))
        if rng.random() < 0.10:
            # User ratings are sparse and include deliberate disagreements with the judge.
            rating=1 if rng.random()<0.48 else -1
            rating_rows.append((turn_id, tr[5], rating))
    cur.executemany('INSERT INTO turn_judge_score VALUES (?,?,?,?,?,?)',judge_rows)
    cur.executemany('INSERT INTO user_explanation_rating VALUES (?,?,?)',rating_rows)
    cur.executemany('INSERT INTO agent_recommendation VALUES (?,?,?,?,?)',rec_rows)

    # Impressions. Concentrate activity around a daily rhythm. A fraction points to recommendations.
    imp_rows=[]; seg_rows=[]; signal_rows=[]; like_rows=[]
    rec_ids=[r[0] for r in rec_rows]
    next_seg=1
    for iid in range(1,N_IMPRESSIONS+1):
        linked_rec = rng.choice(rec_ids) if rec_ids and rng.random() < 0.03 else None
        if linked_rec is not None:
            turn_id, uid, vid, shelf_pos = rec_meta[linked_rec]
        else:
            uid=rng.randint(1,N_USERS); vid=rng.randint(1,N_VIDEOS)
        days_ago=rng.expovariate(0.035); days_ago=min(119,days_ago)
        day=BASE-timedelta(days=days_ago); hour=rng.gauss(19,3); hour=max(0,min(23.9,hour));
        im=day.replace(hour=int(hour),minute=rng.randint(0,59),second=rng.randint(0,59),microsecond=0)
        pos=rng.randint(1,20); rank=f'v{rng.randint(12,19)}'
        imp_rows.append((iid,uid,vid,iso(im),pos,rank))
        # 25% become views; some have 2 segments. Recommendation trace in a subset.
        if rng.random()<0.23:
            nseg=2 if rng.random()<0.11 else 1
            start=im+timedelta(milliseconds=300)
            for s in range(nseg):
                watch= int(max(200, min(160000, rng.lognormvariate(math.log(7000),1.0))))
                end=start+timedelta(milliseconds=watch)
                completed=1 if (linked_rec is not None and rng.random()<0.80) else (1 if watch>15000 and rng.random()<0.35 else 0)
                rr=linked_rec if linked_rec is not None and s==0 else (rng.choice(rec_ids) if (rec_ids and rng.random()<0.01) else None)
                seg_rows.append((next_seg,iid,iso(start),iso(end),watch,completed,rr)); next_seg+=1
                start=end+timedelta(seconds=rng.uniform(.2,3))
        # signals are sparse; likes and retracts are linked deliberately
        if rng.random()<0.045:
            sigt=rng.choice(['like','save','share','comment','follow_from_feed','not_interested','report'])
            st=im+timedelta(seconds=rng.randint(1,300)); dest=rng.choice(['whatsapp','instagram','copied_link']) if sigt=='share' else None
            signal_rows.append((None,uid,vid,sigt,iso(st),dest))
            if sigt=='like' and rng.random()<0.18:
                rt=st+timedelta(seconds=rng.randint(5,55)); signal_rows.append((None,uid,vid,'like_retraction',iso(rt),None)); like_rows.append((uid,vid,iso(st),iso(rt)))
            elif sigt=='like': like_rows.append((uid,vid,iso(st),None))
    cur.executemany('INSERT INTO impression VALUES (?,?,?,?,?,?)',imp_rows)
    cur.executemany('INSERT INTO view_segment VALUES (?,?,?,?,?,?,?)',seg_rows)
    cur.executemany('INSERT INTO engagement_signal(signal_id,user_id,video_id,signal_type,occurred_at,share_destination) VALUES (?,?,?,?,?,?)',[(i+1,*r[1:]) for i,r in enumerate(signal_rows)])
    cur.executemany('INSERT OR REPLACE INTO like_state VALUES (?,?,?,?)',like_rows)

    # Price periods created after model registry and turn usage. Three historical periods per model.
    for model in model_ids.values():
        start=BASE-timedelta(days=180); mids=[start,start+timedelta(days=90)]
        rates={list(model_ids.values())[0]:(0.15,0.60,0.05),list(model_ids.values())[1]:(0.30,0.90,0.10),list(model_ids.values())[2]:(0.08,0.22,0.02)}[model]
        cur.execute('INSERT INTO model_price_period VALUES (?,?,?,?,?,?)',(model,iso(start),iso(mids[1]),*rates))
        rates2=tuple(x*0.9 for x in rates)
        cur.execute('INSERT INTO model_price_period VALUES (?,?,?,?,?,?)',(model,iso(mids[1]),None,*rates2))

    cur.execute('COMMIT')
    conn.close()
    print(f'generated {args.db}: users={N_USERS}, creators={N_CREATORS}, videos={N_VIDEOS}, impressions={N_IMPRESSIONS}, sessions={N_SESSIONS}, turns={len(turn_rows)}, tool_calls={len(tool_rows)}, recommendations={len(rec_rows)}, view_segments={len(seg_rows)}')

if __name__=='__main__': main()
