PRAGMA foreign_keys = ON;

-- F1. Top 10 audio tracks by distinct videos in the last 7 days.
-- Grain: one row per audio track.
WITH recent AS (
  SELECT audio_track_id, video_id
  FROM video
  WHERE audio_track_id IS NOT NULL
    AND uploaded_at >= datetime((SELECT max(uploaded_at) FROM video), '-7 days')
)
SELECT a.track_id, a.title, COUNT(DISTINCT r.video_id) AS distinct_videos
FROM audio_track a JOIN recent r ON r.audio_track_id=a.track_id
GROUP BY a.track_id,a.title
ORDER BY distinct_videos DESC,a.track_id
LIMIT 10;

-- F2. Every creator: total watch hours and mean completion rate for current live clips.
-- First aggregate view segments at video grain; then join to creators to avoid fan-out.
WITH live_videos AS (
  SELECT v.video_id, v.owner_id
  FROM video v JOIN v_video_current_state s ON s.video_id=v.video_id
  WHERE s.state='live'
), per_video AS (
  SELECT lv.owner_id,lv.video_id,
         COUNT(vs.view_segment_id) AS views,
         COALESCE(SUM(vs.watch_ms),0)/3600000.0 AS watch_hours,
         COALESCE(AVG(vs.completed * 1.0),0.0) AS completion_rate
  FROM live_videos lv
  LEFT JOIN impression i ON i.video_id=lv.video_id
  LEFT JOIN view_segment vs ON vs.impression_id=i.impression_id
  GROUP BY lv.owner_id,lv.video_id
)
SELECT c.creator_id,
       COALESCE(SUM(p.watch_hours),0.0) AS total_watch_hours,
       COALESCE(SUM(p.views * p.completion_rate)/NULLIF(SUM(p.views),0),0.0) AS mean_completion_rate
FROM creator c LEFT JOIN per_video p ON p.owner_id=c.creator_id
GROUP BY c.creator_id
ORDER BY total_watch_hours DESC,c.creator_id;

-- F3a. Videos with no audio using NOT IN. Expected to demonstrate NULL poisoning.
SELECT video_id FROM video
WHERE audio_track_id NOT IN (SELECT audio_track_id FROM video)
ORDER BY video_id;

-- F3b. Same intent using NOT EXISTS.
SELECT v.video_id FROM video v
WHERE NOT EXISTS (
  SELECT 1 FROM audio_track a WHERE a.track_id=v.audio_track_id
)
ORDER BY v.video_id;

-- F4. Users who liked then retracted the same clip within 60 seconds.
SELECT DISTINCT l.user_id,l.video_id,l.occurred_at AS liked_at,r.occurred_at AS retracted_at,
       ROUND((julianday(r.occurred_at)-julianday(l.occurred_at))*86400,1) AS seconds_to_retract
FROM engagement_signal l JOIN engagement_signal r
 ON r.user_id=l.user_id AND r.video_id=l.video_id
WHERE l.signal_type='like' AND r.signal_type='like_retraction'
  AND r.occurred_at>l.occurred_at
  AND (julianday(r.occurred_at)-julianday(l.occurred_at))*86400 <= 60
ORDER BY seconds_to_retract,l.user_id,l.video_id;

-- F5. Given hashtag: replace :tag with e.g. 'ai'. Case-insensitive with selected punctuation tolerated.
WITH cleaned AS (
  SELECT video_id,caption,
         trim(replace(replace(replace(replace(lower(caption),'#',' #'),',',' '),'.',' '),'!',' ')) AS c
  FROM video
)
SELECT video_id,caption
FROM cleaned
WHERE c LIKE '% #' || lower(trim(:tag)) || ' %'
  AND instr(' ' || c || ' ', ' #' || lower(trim(:tag)) || ' ') > 0
ORDER BY video_id;
-- NOTE: LIKE is case-insensitive for ASCII, but this expression uses lower()+instr() so the matching
-- logic is explicit. Unicode/Tamil case-folding is not guaranteed by SQLite lower().

-- F6. Users shown a given creator's clips but never engaged with any of them.
-- Replace :creator_id with a real creator id. Set difference is intentional.
SELECT DISTINCT i.user_id
FROM impression i JOIN video v ON v.video_id=i.video_id
WHERE v.owner_id=:creator_id
EXCEPT
SELECT DISTINCT e.user_id
FROM engagement_signal e JOIN video v ON v.video_id=e.video_id
WHERE v.owner_id=:creator_id;

-- UNION vs UNION ALL roll-up for signals. UNION removes duplicate (user,video) pairs.
WITH likes AS (
  SELECT user_id,video_id FROM engagement_signal WHERE signal_type='like'
), saves AS (
  SELECT user_id,video_id FROM engagement_signal WHERE signal_type='save'
)
SELECT
  (SELECT COUNT(*) FROM (SELECT user_id,video_id FROM likes UNION SELECT user_id,video_id FROM saves)) AS union_rows,
  (SELECT COUNT(*) FROM (SELECT user_id,video_id FROM likes UNION ALL SELECT user_id,video_id FROM saves)) AS union_all_rows;

-- F7. Last-month session cost, broken out by prompt version, only sessions over a chosen threshold.
-- Threshold = 0.001 currency units. The HAVING is applied to total session cost, not each version row.
WITH bounds AS (
  SELECT max(started_at) AS mx, datetime(max(started_at),'-1 month') AS lo FROM agent_session
), session_total AS (
  SELECT s.session_id,SUM(tc.turn_cost) AS session_cost
  FROM agent_session s JOIN v_turn_cost tc ON tc.session_id=s.session_id CROSS JOIN bounds b
  WHERE s.started_at >= b.lo AND s.started_at <= b.mx
  GROUP BY s.session_id
  HAVING session_cost > 0.001
)
SELECT st.session_id, tc.template_name, tc.version_no, ROUND(SUM(tc.turn_cost),6) AS cost_for_version
FROM session_total st JOIN v_turn_cost tc ON tc.session_id=st.session_id
GROUP BY st.session_id,tc.template_name,tc.version_no
ORDER BY st.session_id,tc.template_name,tc.version_no;

-- F8. Videos whose moderation state changed more than twice; full ordered sequence.
SELECT video_id,
       COUNT(*)-1 AS transitions,
       group_concat(state,' -> ' ORDER BY valid_from) AS state_sequence
FROM video_moderation_period
GROUP BY video_id
HAVING COUNT(*)-1 > 2
ORDER BY transitions DESC,video_id;

-- F9. Longest consecutive active-day streak, based on view activity.
WITH days AS (
  SELECT user_id, date(started_at) AS day
  FROM impression i JOIN view_segment s ON s.impression_id=i.impression_id
  GROUP BY user_id,date(started_at)
), numbered AS (
  SELECT user_id,day,
         row_number() OVER (PARTITION BY user_id ORDER BY day) AS rn
  FROM days
), islands AS (
  SELECT user_id,day,date(day,'-'||(rn)||' day') AS grp
  FROM numbered
)
SELECT user_id,MAX(streak) AS longest_streak_days
FROM (
  SELECT user_id,grp,COUNT(*) AS streak FROM islands GROUP BY user_id,grp
)
GROUP BY user_id
ORDER BY longest_streak_days DESC,user_id;

-- F10. Creator 7-calendar-day rolling watch time + exact 7-day comparison.
WITH daily AS (
  SELECT v.owner_id AS creator_id,date(s.started_at) AS day,
         SUM(s.watch_ms)/3600000.0 AS watch_hours
  FROM view_segment s JOIN impression i ON i.impression_id=s.impression_id
  JOIN video v ON v.video_id=i.video_id
  GROUP BY v.owner_id,date(s.started_at)
), rolling AS (
  SELECT creator_id,day,
         SUM(watch_hours) OVER (
           PARTITION BY creator_id ORDER BY julianday(day)
           RANGE BETWEEN 6 PRECEDING AND CURRENT ROW
         ) AS rolling_7d_hours
  FROM daily
)
SELECT r.creator_id,r.day,
       DENSE_RANK() OVER (PARTITION BY r.day ORDER BY r.rolling_7d_hours DESC) AS creator_rank,
       ROUND(r.rolling_7d_hours,4) AS rolling_7d_hours,
       ROUND(r.rolling_7d_hours-COALESCE(prev.rolling_7d_hours,0),4) AS wow_change
FROM rolling r
LEFT JOIN rolling prev ON prev.creator_id=r.creator_id AND prev.day=date(r.day,'-7 day')
ORDER BY r.day DESC,creator_rank,r.creator_id
LIMIT 200;

-- F11. Full nesting tree for a given session. Replace :session_id.
WITH RECURSIVE tree AS (
  SELECT tc.tool_call_id,tc.parent_tool_call_id,tc.tool_id,0 AS depth,
         printf('%06d',tc.tool_call_id) AS path
  FROM tool_call tc
  WHERE tc.turn_id IN (SELECT turn_id FROM agent_turn WHERE session_id=:session_id)
    AND tc.parent_tool_call_id IS NULL
  UNION ALL
  SELECT child.tool_call_id,child.parent_tool_call_id,child.tool_id,t.depth+1,
         t.path || '/' || printf('%06d',child.tool_call_id)
  FROM tool_call child JOIN tree t ON child.parent_tool_call_id=t.tool_call_id
)
SELECT tree.tool_call_id,tree.parent_tool_call_id,td.tool_name,tree.depth,tree.path
FROM tree JOIN tool_definition td ON td.tool_id=tree.tool_id
ORDER BY tree.path;

-- F12. Recommended clip watched to completion; recommendation_id is the explicit trace key.
SELECT DISTINCT s.session_id,r.turn_id,r.video_id,r.shelf_position
FROM agent_session s
JOIN agent_turn t ON t.session_id=s.session_id
JOIN agent_recommendation r ON r.turn_id=t.turn_id
JOIN view_segment vs ON vs.recommendation_id=r.recommendation_id AND vs.completed=1
JOIN impression i ON i.impression_id=vs.impression_id
 AND i.user_id=s.user_id AND i.video_id=r.video_id
ORDER BY s.session_id,r.turn_id,r.shelf_position;

-- F13. Judge > 4 but user thumbs-down.
SELECT t.turn_id,t.session_id,j.overall_score,u.rating
FROM agent_turn t
JOIN turn_judge_score j ON j.turn_id=t.turn_id
JOIN user_explanation_rating u ON u.turn_id=t.turn_id
WHERE j.overall_score>4 AND u.rating=-1
ORDER BY j.overall_score DESC,t.turn_id;
-- This disagreement set is commercially valuable because it isolates answers that look good to an
-- automated quality metric but fail the user, making it useful for finding blind spots in the judge rubric.
