DROP VIEW IF EXISTS v_public_profile;
CREATE VIEW v_public_profile AS
SELECT
    u.user_id,
    u.handle,
    u.display_name,
    (SELECT COUNT(*) FROM follow f WHERE f.followed_id=u.user_id AND f.ended_at IS NULL) AS follower_count
FROM app_user u
WHERE u.account_state='active';

DROP VIEW IF EXISTS v_video_current_state;
CREATE VIEW v_video_current_state AS
SELECT v.video_id, v.owner_id, p.state, p.valid_from
FROM video v
JOIN video_moderation_period p ON p.video_id=v.video_id
WHERE p.valid_to IS NULL;

DROP VIEW IF EXISTS v_creator_tier_current;
CREATE VIEW v_creator_tier_current AS
SELECT c.creator_id, p.tier_code, mt.tier_name, p.valid_from
FROM creator c
JOIN creator_tier_period p ON p.creator_id=c.creator_id AND p.valid_to IS NULL
JOIN monetization_tier mt ON mt.tier_code=p.tier_code;

DROP VIEW IF EXISTS v_video_daily_engagement;
CREATE VIEW v_video_daily_engagement AS
WITH base AS (
    SELECT video_id, substr(impression_at,1,10) AS day, COUNT(*) AS impressions
    FROM impression GROUP BY video_id, substr(impression_at,1,10)
),
view_agg AS (
    SELECT i.video_id, substr(s.started_at,1,10) AS day,
           COUNT(DISTINCT s.view_segment_id) AS views,
           COALESCE(SUM(s.watch_ms),0)/1000.0 AS watch_seconds
    FROM impression i JOIN view_segment s ON s.impression_id=i.impression_id
    GROUP BY i.video_id, substr(s.started_at,1,10)
),
like_agg AS (
    SELECT video_id, substr(occurred_at,1,10) AS day,
           SUM(CASE WHEN signal_type='like' THEN 1 WHEN signal_type='like_retraction' THEN -1 ELSE 0 END) AS net_likes
    FROM engagement_signal
    WHERE signal_type IN ('like','like_retraction')
    GROUP BY video_id, substr(occurred_at,1,10)
)
SELECT b.video_id,b.day,b.impressions,
       COALESCE(v.views,0) AS views,
       COALESCE(v.watch_seconds,0) AS watch_seconds,
       COALESCE(l.net_likes,0) AS net_likes
FROM base b
LEFT JOIN view_agg v ON v.video_id=b.video_id AND v.day=b.day
LEFT JOIN like_agg l ON l.video_id=b.video_id AND l.day=b.day;

DROP VIEW IF EXISTS v_turn_cost;
CREATE VIEW v_turn_cost AS
SELECT t.turn_id,t.session_id,t.produced_at,pv.template_name,pv.version_no,
       m.model_name, u.input_tokens,u.output_tokens,u.cached_tokens,
       p.input_rate_per_million,p.output_rate_per_million,p.cached_input_rate_per_million,
       (u.input_tokens*p.input_rate_per_million + u.output_tokens*p.output_rate_per_million + u.cached_tokens*p.cached_input_rate_per_million)/1000000.0 AS turn_cost
FROM agent_turn t
JOIN turn_usage u ON u.turn_id=t.turn_id
JOIN prompt_template_version pv ON pv.prompt_version_id=t.prompt_version_id
JOIN model_registry m ON m.model_id=t.model_id
JOIN model_price_period p ON p.model_id=t.model_id
 AND t.produced_at >= p.valid_from
 AND (p.valid_to IS NULL OR t.produced_at < p.valid_to);
