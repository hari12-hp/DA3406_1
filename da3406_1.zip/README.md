# ScrollSense Assignment 1 - DA24B005

This repository is the complete runnable submission for Assignment 1, Part I/II.

## Contents

- `schema.sql` - 35 relations, constraints, indexes, and integrity triggers, including temporal-overlap checks.
- `views.sql` - the five consumer-facing views required by Deliverable G.
- `transactions.sql` - the three transaction demonstrations and exact manual steps.
- `generate_data.py` - deterministic generator seeded from `DA24B005`.
- `queries.sql` - F1-F13, numbered and commented.
- `run_all.py` - one-command rebuild, load views, execute checks, queries, and transaction tests.
- `check_submission.py` - lighter structural/integrity check.
- `er_diagram.dot` / `er_diagram.png` - ER diagram and source.
- `scrollsense.db` - database produced by the latest run.
- `test_results.json` - latest machine-generated test output used by the report.
- `assignment1_da24b005.pdf` - written report.
- `assignment1_da24b005.docx` - editable report.
- `MANUAL.md` - step-by-step manual, including Windows PowerShell commands.

## Requirements

Python 3.10+ with the standard library only. SQLite 3.44+ is required by the brief; the validation run used SQLite 3.46.1.

No pip packages are required for the database code.

## Fastest way to run everything

From this directory:

```bash
python run_all.py
```

This deletes and recreates `scrollsense.db`, runs `schema.sql`, generates the data in one transaction, loads the views, runs all query checks, and runs the transaction demonstrations.

Expected final checks include:

```text
35 relations
0 foreign-key violations
F2 returns 1800 creators
F3a (NOT IN) returns 0 rows
F3b (NOT EXISTS) returns 5603 rows
F12 returns >0 recommendation-to-completion rows
T1 rolls back both writes after the injected CHECK failure
T2 sees the old committed state from a second connection
T3 reports SQLITE_BUSY while the first writer is open
```

Exact runtimes are machine-dependent and are printed by the script.

## Manual order

1. `python generate_data.py --db scrollsense.db`
2. Load `views.sql` into the database.
3. Run `queries.sql` in SQLite 3.44+.
4. Use `run_all.py` when you want the full automated verification.
5. Use `transactions.sql` with a throwaway copy when demonstrating T1/T2/T3 interactively.

See `MANUAL.md` for the exact commands and parameter values.

## Design note

The database uses ISO-8601 UTC text timestamps consistently. Historical state is retained where the business needs as-of reconstruction: account state periods, creator tier periods, moderation periods, prompt versions, and model price periods. The external views hide these storage choices from consumers.

JSON is used only in `tool_call.arguments_json`, because tool argument shapes vary by tool. The value is guarded with `json_valid()` and is not treated as a substitute for relational tables.
