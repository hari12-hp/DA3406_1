import argparse, os, sqlite3, subprocess, sys, time, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DB=ROOT/'scrollsense.db'

def load_views(c):
    c.executescript((ROOT/'views.sql').read_text())

def run_queries(c):
    # Execute blocks split by labelled comments. Parameterized blocks are supplied here.
    sql=(ROOT/'queries.sql').read_text()
    parts=[]; current=[]; label=None
    for line in sql.splitlines():
        if line.startswith('-- F') and '. ' in line[:8]:
            if current and label: parts.append((label,'\n'.join(current)))
            label=line[3:line.find('.')]
            current=[]
            continue
        if label: current.append(line)
    if current and label: parts.append((label,'\n'.join(current)))
    # F5/F6/F11 are parameterized; F3a/b need separate scripts, UNION query is handled as one.
    out=[]
    for label,block in parts:
        if label in {'F3a','F3b','F5','F6','F11'}:
            continue
        else:
            # F2 etc.
            t=time.perf_counter(); rows=c.execute(block).fetchall(); ms=(time.perf_counter()-t)*1000
            out.append((label,len(rows),rows[:5],ms))
    # explicit parameter runs
    top_creator=c.execute("SELECT v.owner_id FROM impression i JOIN video v ON v.video_id=i.video_id GROUP BY v.owner_id ORDER BY COUNT(*) DESC LIMIT 1").fetchone()[0]
    tests={
      'F3a':("SELECT video_id FROM video WHERE audio_track_id NOT IN (SELECT audio_track_id FROM video) ORDER BY video_id",{}),
      'F3b':("SELECT v.video_id FROM video v WHERE NOT EXISTS (SELECT 1 FROM audio_track a WHERE a.track_id=v.audio_track_id) ORDER BY v.video_id",{}),
      'F5':("WITH cleaned AS (SELECT video_id,caption,trim(replace(replace(replace(replace(lower(caption),'#',' #'),',',' '),'.',' '),'!',' ')) AS c FROM video) SELECT video_id,caption FROM cleaned WHERE c LIKE '% #' || lower(trim(:tag)) || ' %' AND instr(' '||c||' ',' #' || lower(trim(:tag)) || ' ')>0 ORDER BY video_id",{'tag':'ai'}),
      'F6':("SELECT DISTINCT i.user_id FROM impression i JOIN video v ON v.video_id=i.video_id WHERE v.owner_id=? EXCEPT SELECT DISTINCT e.user_id FROM engagement_signal e JOIN video v ON v.video_id=e.video_id WHERE v.owner_id=?",(top_creator,top_creator)),
      'F11':("WITH RECURSIVE tree AS (SELECT tc.tool_call_id,tc.parent_tool_call_id,tc.tool_id,0 AS depth,printf('%06d',tc.tool_call_id) AS path FROM tool_call tc WHERE tc.turn_id IN (SELECT turn_id FROM agent_turn WHERE session_id=1) AND tc.parent_tool_call_id IS NULL UNION ALL SELECT child.tool_call_id,child.parent_tool_call_id,child.tool_id,t.depth+1,t.path||'/'||printf('%06d',child.tool_call_id) FROM tool_call child JOIN tree t ON child.parent_tool_call_id=t.tool_call_id) SELECT tree.tool_call_id,tree.parent_tool_call_id,td.tool_name,tree.depth,tree.path FROM tree JOIN tool_definition td ON td.tool_id=tree.tool_id ORDER BY tree.path",{})
    }
    for label,(q,p) in tests.items():
        t=time.perf_counter(); rows=c.execute(q,p).fetchall(); ms=(time.perf_counter()-t)*1000; out.append((label,len(rows),rows[:5],ms))
    return sorted(out,key=lambda x:(int(''.join(ch for ch in x[0] if ch.isdigit()) or 0), x[0]))

def transaction_tests():
    # T1: failure rolls back both state update and retraction signal.
    c=sqlite3.connect(DB); c.execute('PRAGMA foreign_keys=ON')
    row=c.execute("SELECT user_id,video_id,liked_at FROM like_state WHERE retracted_at IS NULL LIMIT 1").fetchone()
    if not row:
        return {'T1':'SKIP no active like'}
    uid,vid,liked=row; before=c.execute("SELECT retracted_at FROM like_state WHERE user_id=? AND video_id=?",(uid,vid)).fetchone()[0]
    try:
        c.execute('BEGIN')
        rt='2026-08-31T12:00:00Z'
        c.execute("UPDATE like_state SET retracted_at=? WHERE user_id=? AND video_id=?",(rt,uid,vid))
        c.execute("INSERT INTO engagement_signal(user_id,video_id,signal_type,occurred_at) VALUES (?,?,?,?)",(uid,vid,'like_retraction',rt))
        c.execute("INSERT INTO engagement_signal(user_id,video_id,signal_type,occurred_at) VALUES (?,?,?,?)",(uid,vid,'BROKEN',rt))
        c.commit(); status='unexpected commit'
    except Exception as e:
        c.rollback(); status=str(e)
    after=c.execute("SELECT retracted_at FROM like_state WHERE user_id=? AND video_id=?",(uid,vid)).fetchone()[0]
    orphan=c.execute("SELECT COUNT(*) FROM engagement_signal WHERE user_id=? AND video_id=? AND signal_type='like_retraction' AND occurred_at=?",(uid,vid,'2026-08-31T12:00:00Z')).fetchone()[0]
    # T3a: three handle changes within one rolling year. First two succeed, third fails. Roll back test.
    u= c.execute("SELECT user_id,handle FROM app_user WHERE account_state='active' LIMIT 1").fetchone(); hu,hh=u
    try:
        c.execute('BEGIN')
        c.execute("UPDATE app_user SET handle=? WHERE user_id=?",(hh+'a',hu))
        c.execute("UPDATE app_user SET handle=? WHERE user_id=?",(hh+'b',hu))
        try:
            c.execute("UPDATE app_user SET handle=? WHERE user_id=?",(hh+'c',hu))
            herror='unexpectedly succeeded'
        except Exception as e:
            herror=str(e)
        c.rollback()
    except Exception:
        c.rollback(); raise
    c.close(); return {'T1':{'error':status,'like_unchanged':after==before,'retraction_rows_after':orphan}, 'T3a':{'third_change_error':herror}}

def concurrency_tests():
    c1=sqlite3.connect(DB, timeout=5.0, isolation_level=None)
    c2=sqlite3.connect(DB, timeout=0.0, isolation_level=None)
    # T2: uncommitted moderation decision is invisible to other connection.
    vid=c1.execute('SELECT video_id FROM video LIMIT 1').fetchone()[0]
    prior=c2.execute('SELECT state FROM v_video_current_state WHERE video_id=?',(vid,)).fetchone()[0]
    row=c1.execute("SELECT decision_id FROM moderation_decision ORDER BY decision_id DESC LIMIT 1").fetchone(); dec_id=row[0]+1
    vf='2026-09-01T12:00:00Z'
    try:
        c1.execute('BEGIN IMMEDIATE')
        c1.execute("UPDATE video_moderation_period SET valid_to=? WHERE video_id=? AND valid_to IS NULL",(vf,vid))
        c1.execute("INSERT INTO moderation_decision VALUES (?,?,?,?,?,?)",(dec_id,vid,vf,'human_reviewer','tx-test','tx-test'))
        c1.execute("INSERT INTO video_moderation_period VALUES (?,?,?,?,?)",(vid,dec_id,'live',vf,None))
        seen=c2.execute('SELECT state FROM v_video_current_state WHERE video_id=?',(vid,)).fetchone()[0]
        c1.execute('ROLLBACK')
    except Exception:
        c1.execute('ROLLBACK'); raise
    # T3 writer serialization while a transaction is open.
    busy_error=None
    c1.execute('BEGIN IMMEDIATE')
    try:
        c2.execute("UPDATE app_user SET display_name=display_name WHERE user_id=1")
    except Exception as e: busy_error={'message':str(e),'sqlite_errorname':getattr(e,'sqlite_errorname',None)}
    c1.execute('ROLLBACK')
    c1.close(); c2.close()
    return {'T2':{'prior_state':prior,'second_connection_state_before_commit':seen,'invisible':seen==prior}, 'T3':{'writer_error':busy_error}}

def schema_checks():
    c=sqlite3.connect(DB)
    tables=c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()
    fk=c.execute('PRAGMA foreign_key_check').fetchall()
    try:
        c.execute('CREATE TEMP TABLE strict_test(x INTEGER) STRICT')
        strict_error=None
        try: c.execute("INSERT INTO strict_test VALUES ('not an integer')")
        except Exception as e: strict_error=str(e)
    finally: pass
    view_error=None
    try: c.execute("INSERT INTO v_public_profile(user_id,handle,display_name,follower_count) VALUES (99999,'x','x',0)")
    except Exception as e: view_error=str(e)
    c.close(); return {'table_count':len(tables),'tables':[x[0] for x in tables],'fk_violations':len(fk),'strict_error':strict_error,'view_insert_error':view_error}

def main():
    subprocess.run([sys.executable,str(ROOT/'generate_data.py'),'--db',str(DB)],check=True)
    c=sqlite3.connect(DB); c.execute('PRAGMA foreign_keys=ON'); load_views(c); c.commit()
    schema=schema_checks(); q=run_queries(c); tx1=transaction_tests(); tx23=concurrency_tests();
    # Recheck foreign keys after tests and after rollback.
    schema['fk_violations_after']=len(c.execute('PRAGMA foreign_key_check').fetchall())
    c.close()
    result={'schema':schema,'queries':[(a,b,d,e) for a,b,_,d,e in []]}
    result['query_summary']=[{'id':a,'rows':b,'first5':d,'runtime_ms':round(e,3)} for a,b,d,e in q]
    result['transactions']={**tx1,**tx23}
    (ROOT/'test_results.json').write_text(json.dumps(result,indent=2,default=str))
    print(json.dumps(result,indent=2,default=str))

if __name__=='__main__': main()
